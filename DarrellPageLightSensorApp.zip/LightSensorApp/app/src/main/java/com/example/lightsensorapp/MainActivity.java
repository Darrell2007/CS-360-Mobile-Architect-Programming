package com.example.lightsensorapp;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class MainActivity extends AppCompatActivity
        implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor lightSensor;

    private TextView textLight;
    private TextView textBrightness;
    private TextView textStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textLight = findViewById(R.id.textLight);
        textBrightness = findViewById(R.id.textBrightness);
        textStatus = findViewById(R.id.textStatus);

        sensorManager = (SensorManager)
                getSystemService(SENSOR_SERVICE);

        lightSensor = sensorManager.getDefaultSensor(
                Sensor.TYPE_LIGHT);

        if (lightSensor == null) {
            textStatus.setText("Light Sensor Not Available");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (lightSensor != null) {
            sensorManager.registerListener(
                    this,
                    lightSensor,
                    SensorManager.SENSOR_DELAY_NORMAL
            );

            textStatus.setText("Sensor Status: Active");
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {

        if (event.sensor.getType() == Sensor.TYPE_LIGHT) {

            float light = event.values[0];

            textLight.setText(String.format(
                    Locale.US,
                    "Light Level: %.1f lux", light));

            if (light < 100) {
                textBrightness.setText("Brightness: Dim");
            } else if (light < 1000) {
                textBrightness.setText("Brightness: Normal");
            } else {
                textBrightness.setText("Brightness: Bright");
            }
        }
    }

    @Override
    public void onAccuracyChanged(
            Sensor sensor, int accuracy) {
        // No action needed
    }
}
