package com.example.eventtrackerapp;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class SMSActivity extends Activity {

    private static final int SMS_REQUEST_CODE = 101;
    private static final int REMINDER_REQUEST_CODE = 200;

    public static final String PREFS = "sms_settings";

    private static final String KEY_PHONE = "phone";
    private static final String KEY_ENABLED = "enabled";

    private TextView txtPermissionStatus;
    private EditText editPhoneNumber;
    private Switch switchSMS;

    private Button btnRequestPermission;
    private Button btnSaveSMS;
    private Button btnTestSMS;
    private Button btnBack;

    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_sms);

        // Connect Java to XML
        txtPermissionStatus =
                findViewById(R.id.txtPermissionStatus);

        editPhoneNumber =
                findViewById(R.id.editPhoneNumber);

        switchSMS =
                findViewById(R.id.switchSMS);

        btnRequestPermission =
                findViewById(R.id.btnRequestPermission);

        btnSaveSMS =
                findViewById(R.id.btnSaveSMS);

        btnTestSMS =
                findViewById(R.id.btnTestSMS);

        btnBack =
                findViewById(R.id.btnBack);

        // Load previously saved SMS settings
        preferences = getSharedPreferences(
                PREFS,
                MODE_PRIVATE
        );

        editPhoneNumber.setText(
                preferences.getString(KEY_PHONE, "")
        );

        switchSMS.setChecked(
                preferences.getBoolean(KEY_ENABLED, false)
        );

        // Request SMS permission
        btnRequestPermission.setOnClickListener(v -> {

            if (!hasSMSPermission()) {

                requestPermissions(
                        new String[]{
                                Manifest.permission.SEND_SMS
                        },
                        SMS_REQUEST_CODE
                );

            } else {

                showMessage(
                        "SMS permission is already granted"
                );
            }
        });

        // Save notification preferences
        btnSaveSMS.setOnClickListener(v -> saveSettings());

        // Send a test SMS
        btnTestSMS.setOnClickListener(v -> sendTestSMS());

        // Return to Event Dashboard
        btnBack.setOnClickListener(v -> finish());

        updatePermissionStatus();
    }

    // Check whether the device supports SMS
    private boolean supportsSMS() {

        return getPackageManager().hasSystemFeature(
                PackageManager.FEATURE_TELEPHONY_MESSAGING
        );
    }

    // Check runtime SMS permission
    private boolean hasSMSPermission() {

        return checkSelfPermission(
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED;
    }

    // Check whether reminders can currently operate
    private boolean canSendSMS() {

        return supportsSMS() && hasSMSPermission();
    }

    // Display permission status
    private void updatePermissionStatus() {

        if (!supportsSMS()) {

            txtPermissionStatus.setText(
                    "SMS Status: Not supported on this device"
            );

            txtPermissionStatus.setTextColor(
                    0xFFFF8282
            );

            btnRequestPermission.setEnabled(false);
            btnTestSMS.setEnabled(false);

        } else if (hasSMSPermission()) {

            txtPermissionStatus.setText(
                    "SMS Permission: GRANTED"
            );

            txtPermissionStatus.setTextColor(
                    0xFF36D9D0
            );

            btnRequestPermission.setEnabled(false);
            btnTestSMS.setEnabled(true);

        } else {

            txtPermissionStatus.setText(
                    "SMS Permission: NOT GRANTED"
            );

            txtPermissionStatus.setTextColor(
                    0xFFFF8282
            );

            btnRequestPermission.setEnabled(true);
            btnTestSMS.setEnabled(false);
        }
    }

    // Save phone number and reminder settings
    private void saveSettings() {

        String phone = editPhoneNumber
                .getText()
                .toString()
                .trim();

        boolean enabled = switchSMS.isChecked();

        // Validate the phone number when enabling
        if (enabled && !isValidPhone(phone)) {

            showMessage(
                    "Enter a valid phone number first"
            );

            return;
        }

        // Do not enable SMS without permission
        if (enabled && !canSendSMS()) {

            switchSMS.setChecked(false);

            preferences.edit()
                    .putBoolean(KEY_ENABLED, false)
                    .apply();

            cancelReminderCheck();

            showMessage(
                    "SMS unavailable. Events will still work."
            );

            updatePermissionStatus();
            return;
        }

        // Store settings
        preferences.edit()
                .putString(KEY_PHONE, phone)
                .putBoolean(KEY_ENABLED, enabled)
                .apply();

        if (enabled) {

            scheduleReminderCheck();

            showMessage(
                    "SMS reminders enabled and saved"
            );

        } else {

            cancelReminderCheck();

            showMessage(
                    "SMS reminders disabled"
            );
        }
    }

    // Basic phone number validation
    private boolean isValidPhone(String phone) {

        return phone.matches("\\+?[0-9]{7,15}");
    }

    // Send a test notification
    private void sendTestSMS() {

        if (!canSendSMS()) {

            showMessage(
                    "SMS permission or device support unavailable"
            );

            return;
        }

        boolean enabled = preferences.getBoolean(
                KEY_ENABLED,
                false
        );

        if (!enabled) {

            showMessage(
                    "Enable and save SMS reminders first"
            );

            return;
        }

        String phone = preferences.getString(
                KEY_PHONE,
                ""
        );

        if (!isValidPhone(phone)) {

            showMessage(
                    "Save a valid phone number first"
            );

            return;
        }

        String message =
                "EventTracker TEST: " +
                        "Your SMS event reminders are enabled.";

        try {

            SmsManager smsManager =
                    getSystemService(SmsManager.class);

            if (smsManager == null) {

                showMessage(
                        "SMS service is unavailable"
                );

                return;
            }

            smsManager.sendTextMessage(
                    phone,
                    null,
                    message,
                    null,
                    null
            );

            showMessage(
                    "Test SMS submitted for sending"
            );

        } catch (Exception e) {

            showMessage(
                    "SMS could not be sent: " +
                            e.getClass().getSimpleName()
            );
        }
    }

    // Schedule a daily event reminder check
    private void scheduleReminderCheck() {

        AlarmManager alarmManager =
                (AlarmManager) getSystemService(
                        ALARM_SERVICE
                );

        if (alarmManager == null) {
            showMessage("Alarm service unavailable");
            return;
        }

        Intent intent = new Intent(
                this,
                EventReminderReceiver.class
        );

        PendingIntent pendingIntent =
                PendingIntent.getBroadcast(
                        this,
                        REMINDER_REQUEST_CODE,
                        intent,
                        PendingIntent.FLAG_UPDATE_CURRENT |
                                PendingIntent.FLAG_IMMUTABLE
                );

        Calendar calendar = Calendar.getInstance();

        // Check upcoming events around 9:00 AM
        calendar.set(
                Calendar.HOUR_OF_DAY,
                9
        );

        calendar.set(
                Calendar.MINUTE,
                0
        );

        calendar.set(
                Calendar.SECOND,
                0
        );

        calendar.set(
                Calendar.MILLISECOND,
                0
        );

        // Schedule tomorrow if 9 AM has passed
        if (calendar.getTimeInMillis()
                <= System.currentTimeMillis()) {

            calendar.add(
                    Calendar.DAY_OF_YEAR,
                    1
            );
        }

        // Inexact repeating alarm; no exact-alarm
        // permission is required
        alarmManager.setInexactRepeating(
                AlarmManager.RTC_WAKEUP,
                calendar.getTimeInMillis(),
                AlarmManager.INTERVAL_DAY,
                pendingIntent
        );
    }

    // Cancel previously scheduled reminders
    private void cancelReminderCheck() {

        AlarmManager alarmManager =
                (AlarmManager) getSystemService(
                        ALARM_SERVICE
                );

        Intent intent = new Intent(
                this,
                EventReminderReceiver.class
        );

        PendingIntent pendingIntent =
                PendingIntent.getBroadcast(
                        this,
                        REMINDER_REQUEST_CODE,
                        intent,
                        PendingIntent.FLAG_NO_CREATE |
                                PendingIntent.FLAG_IMMUTABLE
                );

        if (alarmManager != null &&
                pendingIntent != null) {

            alarmManager.cancel(pendingIntent);
            pendingIntent.cancel();
        }
    }

    // Handle permission response
    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );

        if (requestCode == SMS_REQUEST_CODE) {

            boolean granted =
                    grantResults.length > 0 &&
                            grantResults[0] ==
                                    PackageManager.PERMISSION_GRANTED;

            if (granted) {

                showMessage(
                        "SMS permission granted. " +
                                "Enable reminders and save."
                );

            } else {

                // Keep the rest of EventTracker working
                switchSMS.setChecked(false);

                preferences.edit()
                        .putBoolean(KEY_ENABLED, false)
                        .apply();

                cancelReminderCheck();

                showMessage(
                        "SMS permission denied. " +
                                "You can still manage your events."
                );
            }

            updatePermissionStatus();
        }
    }

    // Refresh permission state when returning
    // from Android Settings
    @Override
    protected void onResume() {
        super.onResume();

        if (txtPermissionStatus != null) {

            updatePermissionStatus();

            if (!canSendSMS()) {

                switchSMS.setChecked(false);

                preferences.edit()
                        .putBoolean(KEY_ENABLED, false)
                        .apply();

                cancelReminderCheck();
            }
        }
    }

    // Display feedback
    private void showMessage(String message) {

        Toast.makeText(
                this,
                message,
                Toast.LENGTH_SHORT
        ).show();
    }
}
