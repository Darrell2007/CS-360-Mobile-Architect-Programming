package com.example.eventtrackerapp;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.telephony.SmsManager;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class EventReminderReceiver
        extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        SharedPreferences prefs =
                context.getSharedPreferences(
                        SMSActivity.PREFS,
                        Context.MODE_PRIVATE);

        if (!prefs.getBoolean("enabled", false)) {
            return;
        }

        if (context.checkSelfPermission(
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        String phone = prefs.getString("phone", "");

        if (!phone.matches("\\+?[0-9]{7,15}")) {
            return;
        }

        Calendar tomorrow = Calendar.getInstance();
        tomorrow.add(Calendar.DAY_OF_YEAR, 1);

        String targetDate = new SimpleDateFormat(
                "yyyy-MM-dd", Locale.US)
                .format(tomorrow.getTime());

        EventDatabaseHelper db =
                new EventDatabaseHelper(context);

        try (Cursor cursor = db.getAllEvents()) {

            while (cursor.moveToNext()) {
                String eventName = cursor.getString(1);
                String eventDate = cursor.getString(2);

                if (targetDate.equals(eventDate)) {
                    SmsManager manager =
                            context.getSystemService(
                                    SmsManager.class);

                    manager.sendTextMessage(
                            phone,
                            null,
                            "EventTracker Reminder: " +
                                    eventName +
                                    " is tomorrow (" +
                                    eventDate + ").",
                            null,
                            null
                    );
                }
            }

        } catch (Exception e) {
            android.util.Log.e(
                    "EventTracker",
                    "Reminder processing failed",
                    e);
        } finally {
            db.close();
        }
    }
}
