package com.example.eventtrackerapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class EventDatabaseHelper extends SQLiteOpenHelper {

    // Database information
    private static final String DATABASE_NAME =
            "EventTrackerEvents.db";

    private static final int DATABASE_VERSION = 1;

    // Events table
    public static final String TABLE_EVENTS = "events";

    // Column names
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NAME = "event_name";
    public static final String COLUMN_DATE = "event_date";

    // Constructor
    public EventDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Create the database table
    @Override
    public void onCreate(SQLiteDatabase db) {

        String createEventsTable =
                "CREATE TABLE " + TABLE_EVENTS + " (" +
                        COLUMN_ID +
                        " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_NAME + " TEXT NOT NULL, " +
                        COLUMN_DATE + " TEXT NOT NULL" +
                        ")";

        db.execSQL(createEventsTable);
    }

    // Handle future database upgrades
    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion) {

        // Version 1 has no migrations yet.
        // Future schema changes should be migrated here
        // without deleting existing event records.
    }

    // CREATE: Add a new event
    public long addEvent(String name, String date) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(COLUMN_NAME, name);
        values.put(COLUMN_DATE, date);

        return db.insert(
                TABLE_EVENTS,
                null,
                values
        );
    }

    // READ: Retrieve all saved events
    public Cursor getAllEvents() {

        SQLiteDatabase db = getReadableDatabase();

        return db.query(
                TABLE_EVENTS,
                new String[]{
                        COLUMN_ID,
                        COLUMN_NAME,
                        COLUMN_DATE
                },
                null,
                null,
                null,
                null,
                COLUMN_DATE + " ASC, " +
                        COLUMN_ID + " ASC"
        );
    }

    // UPDATE: Modify an existing event
    public int updateEvent(
            long id,
            String name,
            String date) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(COLUMN_NAME, name);
        values.put(COLUMN_DATE, date);

        return db.update(
                TABLE_EVENTS,
                values,
                COLUMN_ID + " = ?",
                new String[]{
                        String.valueOf(id)
                }
        );
    }

    // DELETE: Remove an event
    public int deleteEvent(long id) {

        SQLiteDatabase db = getWritableDatabase();

        return db.delete(
                TABLE_EVENTS,
                COLUMN_ID + " = ?",
                new String[]{
                        String.valueOf(id)
                }
        );
    }
}
