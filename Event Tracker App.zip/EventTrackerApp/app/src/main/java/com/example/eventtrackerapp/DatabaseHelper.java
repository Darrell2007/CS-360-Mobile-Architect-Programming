package com.example.eventtrackerapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.security.MessageDigest;
import java.security.SecureRandom;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME =
            "EventTracker.db";

    private static final int DATABASE_VERSION = 1;
    private static final int ITERATIONS = 600000;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null,
                DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(
                "CREATE TABLE IF NOT EXISTS users (" +
                        "username TEXT PRIMARY KEY, " +
                        "salt BLOB NOT NULL, " +
                        "password_hash BLOB NOT NULL)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion,
                          int newVersion) {
        // Preserve existing accounts.
        // Add migrations here for future versions.
    }

    private byte[] hashPassword(
            String password, byte[] salt) throws Exception {

        PBEKeySpec spec = new PBEKeySpec(
                password.toCharArray(),
                salt,
                ITERATIONS,
                256
        );

        try {
            SecretKeyFactory factory =
                    SecretKeyFactory.getInstance(
                            "PBKDF2WithHmacSHA256");

            return factory.generateSecret(spec)
                    .getEncoded();

        } finally {
            spec.clearPassword();
        }
    }

    public boolean usernameExists(String username) {

        SQLiteDatabase db = getReadableDatabase();

        try (Cursor cursor = db.rawQuery(
                "SELECT username FROM users " +
                        "WHERE username = ?",
                new String[]{username})) {

            return cursor.moveToFirst();
        }
    }

    public boolean createAccount(
            String username, String password) {

        if (username.isEmpty() ||
                password.length() < 8) {
            return false;
        }

        try {
            byte[] salt = new byte[16];
            new SecureRandom().nextBytes(salt);

            byte[] hash = hashPassword(password, salt);

            ContentValues values = new ContentValues();

            values.put("username", username);
            values.put("salt", salt);
            values.put("password_hash", hash);

            long result = getWritableDatabase().insert(
                    "users",
                    null,
                    values
            );

            return result != -1;

        } catch (Exception e) {
            return false;
        }
    }

    public boolean checkLogin(
            String username, String password) {

        SQLiteDatabase db = getReadableDatabase();

        try (Cursor cursor = db.rawQuery(
                "SELECT salt, password_hash " +
                        "FROM users WHERE username = ?",
                new String[]{username})) {

            if (!cursor.moveToFirst()) {
                return false;
            }

            byte[] salt = cursor.getBlob(0);
            byte[] savedHash = cursor.getBlob(1);
            byte[] enteredHash =
                    hashPassword(password, salt);

            return MessageDigest.isEqual(
                    savedHash, enteredHash);

        } catch (Exception e) {
            return false;
        }
    }
}
