package com.example.eventtrackerapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class EventGridActivity extends Activity {

    // Navy & Aqua colors
    private static final int NAVY =
            Color.rgb(7, 27, 51);

    private static final int AQUA =
            Color.rgb(54, 217, 208);

    private static final int BLUE =
            Color.rgb(23, 69, 107);

    private static final int RED =
            Color.rgb(160, 40, 50);

    // UI components
    private EditText editEventName;
    private EditText editEventDate;

    private Button btnAddEvent;
    private Button btnSMSNotifications;

    private TableLayout tableEvents;

    // SQLite database
    private EventDatabaseHelper databaseHelper;

    // Background database operations
    private final ExecutorService executor =
            Executors.newSingleThreadExecutor();

    // -1 means we are adding a new event
    private long editingEventId = -1;

    private boolean busy = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_event_grid);

        // Connect Java to XML components
        editEventName =
                findViewById(R.id.editEventName);

        editEventDate =
                findViewById(R.id.editEventDate);

        btnAddEvent =
                findViewById(R.id.btnAddEvent);

        btnSMSNotifications =
                findViewById(R.id.btnSMSNotifications);

        tableEvents =
                findViewById(R.id.tableEvents);

        // Initialize SQLite database
        databaseHelper =
                new EventDatabaseHelper(this);

        // Add or update event
        btnAddEvent.setOnClickListener(v -> saveEvent());

        // Open SMS Notifications screen
        btnSMSNotifications.setOnClickListener(v -> {

            Intent intent = new Intent(
                    EventGridActivity.this,
                    SMSActivity.class
            );

            startActivity(intent);
        });

        // Display saved events
        loadEvents();
    }

    // Convert dp to pixels for consistent column widths
    private int dpToPx(int dp) {

        return Math.round(
                dp * getResources()
                        .getDisplayMetrics().density
        );
    }

    // Check date format YYYY-MM-DD
    private boolean isValidDate(String date) {

        if (!date.matches("\\d{4}-\\d{2}-\\d{2}")) {
            return false;
        }

        SimpleDateFormat format =
                new SimpleDateFormat(
                        "yyyy-MM-dd",
                        Locale.US
                );

        format.setLenient(false);

        ParsePosition position =
                new ParsePosition(0);

        return format.parse(date, position) != null
                && position.getIndex() == date.length();
    }

    // Disable buttons during database operations
    private void setBusy(boolean value) {

        busy = value;

        btnAddEvent.setEnabled(!value);
        btnSMSNotifications.setEnabled(!value);
    }

    // CREATE OR UPDATE
    private void saveEvent() {

        if (busy) {
            return;
        }

        String name = editEventName
                .getText().toString().trim();

        String date = editEventDate
                .getText().toString().trim();

        if (name.isEmpty()) {

            showMessage("Please enter an event name");
            return;
        }

        if (!isValidDate(date)) {

            showMessage(
                    "Enter a valid date: YYYY-MM-DD"
            );
            return;
        }

        final long eventId = editingEventId;

        setBusy(true);

        executor.execute(() -> {

            boolean success;

            if (eventId == -1) {

                // CREATE
                long result =
                        databaseHelper.addEvent(name, date);

                success = result != -1;

            } else {

                // UPDATE
                int result =
                        databaseHelper.updateEvent(
                                eventId,
                                name,
                                date
                        );

                success = result > 0;
            }

            runOnUiThread(() -> {

                setBusy(false);

                if (success) {

                    if (eventId == -1) {

                        showMessage(
                                "Event added successfully!"
                        );

                    } else {

                        showMessage(
                                "Event updated successfully!"
                        );
                    }

                    clearFields();
                    loadEvents();

                } else {

                    showMessage(
                            "Unable to save event"
                    );
                }
            });
        });
    }

    // READ: Load all events from SQLite
    private void loadEvents() {

        executor.execute(() -> {

            java.util.ArrayList<EventItem> events =
                    new java.util.ArrayList<>();

            try (Cursor cursor =
                         databaseHelper.getAllEvents()) {

                while (cursor.moveToNext()) {

                    long id = cursor.getLong(0);
                    String name = cursor.getString(1);
                    String date = cursor.getString(2);

                    events.add(
                            new EventItem(id, name, date)
                    );
                }
            }

            runOnUiThread(() -> displayEvents(events));
        });
    }

    // Display SQLite records as grid rows
    private void displayEvents(
            java.util.ArrayList<EventItem> events) {

        tableEvents.removeAllViews();

        for (EventItem event : events) {

            TableRow row = new TableRow(this);

            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dpToPx(4),
                    0, dpToPx(4));

            // EVENT NAME
            TextView nameView = new TextView(this);

            nameView.setText(event.name);
            nameView.setTextColor(Color.WHITE);
            nameView.setTextSize(13);
            nameView.setPadding(
                    dpToPx(6), dpToPx(6),
                    dpToPx(6), dpToPx(6)
            );

            nameView.setLayoutParams(
                    new TableRow.LayoutParams(
                            dpToPx(120),
                            TableRow.LayoutParams.WRAP_CONTENT
                    )
            );

            // EVENT DATE
            TextView dateView = new TextView(this);

            dateView.setText(event.date);
            dateView.setTextColor(Color.WHITE);
            dateView.setTextSize(12);
            dateView.setPadding(
                    dpToPx(6), dpToPx(6),
                    dpToPx(6), dpToPx(6)
            );

            dateView.setLayoutParams(
                    new TableRow.LayoutParams(
                            dpToPx(110),
                            TableRow.LayoutParams.WRAP_CONTENT
                    )
            );

            // EDIT BUTTON
            Button editButton = new Button(this);

            editButton.setText("EDIT");
            editButton.setTextSize(10);
            editButton.setTextColor(Color.WHITE);

            editButton.setBackgroundTintList(
                    ColorStateList.valueOf(BLUE)
            );

            editButton.setMinHeight(dpToPx(48));
            editButton.setMinimumHeight(dpToPx(48));

            editButton.setLayoutParams(
                    new TableRow.LayoutParams(
                            dpToPx(85),
                            dpToPx(48)
                    )
            );

            editButton.setOnClickListener(v ->
                    editEvent(event));

            // DELETE BUTTON
            Button deleteButton = new Button(this);

            deleteButton.setText("DELETE");
            deleteButton.setTextSize(10);
            deleteButton.setTextColor(Color.WHITE);

            deleteButton.setBackgroundTintList(
                    ColorStateList.valueOf(RED)
            );

            deleteButton.setMinHeight(dpToPx(48));
            deleteButton.setMinimumHeight(dpToPx(48));

            deleteButton.setLayoutParams(
                    new TableRow.LayoutParams(
                            dpToPx(100),
                            dpToPx(48)
                    )
            );

            deleteButton.setOnClickListener(v ->
                    confirmDelete(event.id));

            // Add all four columns
            row.addView(nameView);
            row.addView(dateView);
            row.addView(editButton);
            row.addView(deleteButton);

            // Add row to grid
            tableEvents.addView(row);
        }

        if (events.isEmpty()) {

            TableRow emptyRow = new TableRow(this);

            TextView emptyText = new TextView(this);

            emptyText.setText(
                    "No events saved yet. Add your first event!"
            );

            emptyText.setTextColor(AQUA);
            emptyText.setPadding(
                    dpToPx(8), dpToPx(20),
                    dpToPx(8), dpToPx(20)
            );

            emptyRow.addView(emptyText);

            tableEvents.addView(emptyRow);
        }
    }

    // UPDATE: Select event for editing
    private void editEvent(EventItem event) {

        if (busy) {
            return;
        }

        editingEventId = event.id;

        editEventName.setText(event.name);
        editEventDate.setText(event.date);

        btnAddEvent.setText("SAVE CHANGES");

        editEventName.requestFocus();

        showMessage(
                "Edit the event and tap SAVE CHANGES"
        );
    }

    // DELETE: Ask for confirmation
    private void confirmDelete(long eventId) {

        if (busy) {
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("Delete Event")
                .setMessage(
                        "Are you sure you want to delete this event?"
                )
                .setPositiveButton(
                        "DELETE",
                        (dialog, which) ->
                                deleteEvent(eventId)
                )
                .setNegativeButton("CANCEL", null)
                .show();
    }

    // DELETE: Remove event from SQLite
    private void deleteEvent(long eventId) {

        setBusy(true);

        executor.execute(() -> {

            int result =
                    databaseHelper.deleteEvent(eventId);

            runOnUiThread(() -> {

                setBusy(false);

                if (result > 0) {

                    if (editingEventId == eventId) {
                        clearFields();
                    }

                    showMessage("Event deleted");
                    loadEvents();

                } else {

                    showMessage(
                            "Unable to delete event"
                    );
                }
            });
        });
    }

    // Clear event input fields
    private void clearFields() {

        editEventName.setText("");
        editEventDate.setText("");

        editingEventId = -1;

        btnAddEvent.setText("ADD EVENT");
    }

    // Display a short message
    private void showMessage(String message) {

        Toast.makeText(
                this,
                message,
                Toast.LENGTH_SHORT
        ).show();
    }

    // Event data model
    private static class EventItem {

        long id;
        String name;
        String date;

        EventItem(long id,
                  String name,
                  String date) {

            this.id = id;
            this.name = name;
            this.date = date;
        }
    }

    @Override
    protected void onDestroy() {

        executor.shutdown();

        // SQLiteOpenHelper manages the database.
        // Avoid closing it while queued work is running.

        super.onDestroy();
    }
}
