package com.example.eventtrackerapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private EditText editUsername;
    private EditText editPassword;

    private Button btnLogin;
    private Button btnCreateAccount;

    private DatabaseHelper databaseHelper;

    private final ExecutorService executor =
            Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        editUsername =
                findViewById(R.id.editUsername);

        editPassword =
                findViewById(R.id.editPassword);

        btnLogin =
                findViewById(R.id.btnLogin);

        btnCreateAccount =
                findViewById(R.id.btnCreateAccount);

        databaseHelper = new DatabaseHelper(this);

        btnCreateAccount.setOnClickListener(v ->
                createNewAccount());

        btnLogin.setOnClickListener(v ->
                loginUser());
    }

    private void setButtonsEnabled(boolean enabled) {
        btnLogin.setEnabled(enabled);
        btnCreateAccount.setEnabled(enabled);
    }

    // CREATE NEW ACCOUNT
    private void createNewAccount() {

        String username = editUsername.getText()
                .toString().trim();

        String password = editPassword.getText()
                .toString();

        if (username.isEmpty() || password.isEmpty()) {
            showMessage("Please fill in both fields");
            return;
        }

        if (password.length() < 8) {
            showMessage(
                    "Password must be at least 8 characters");
            return;
        }

        setButtonsEnabled(false);

        executor.execute(() -> {

            boolean exists =
                    databaseHelper.usernameExists(username);

            boolean created = false;

            if (!exists) {
                created = databaseHelper.createAccount(
                        username, password);
            }

            final boolean accountExists = exists;
            final boolean accountCreated = created;

            runOnUiThread(() -> {

                setButtonsEnabled(true);

                if (accountExists) {

                    showMessage("Username already exists");

                } else if (accountCreated) {

                    showMessage(
                            "Account created successfully!");

                    editPassword.setText("");

                } else {

                    showMessage(
                            "Unable to create account");
                }
            });
        });
    }

    // LOGIN EXISTING USER
    private void loginUser() {

        String username = editUsername.getText()
                .toString().trim();

        String password = editPassword.getText()
                .toString();

        if (username.isEmpty() || password.isEmpty()) {
            showMessage(
                    "Enter username and password");
            return;
        }

        setButtonsEnabled(false);

        executor.execute(() -> {

            boolean valid =
                    databaseHelper.checkLogin(
                            username, password);

            runOnUiThread(() -> {

                setButtonsEnabled(true);

                if (valid) {

                    showMessage(
                            "Login successful! Welcome "
                                    + username);

                    Intent intent = new Intent(
                            MainActivity.this,
                            EventGridActivity.class
                    );

                    startActivity(intent);

                } else {

                    showMessage(
                            "Invalid username or password");
                }
            });
        });
    }

    private void showMessage(String message) {

        Toast.makeText(
                this,
                message,
                Toast.LENGTH_SHORT
        ).show();
    }

    @Override
    protected void onDestroy() {
        executor.shutdown();
        super.onDestroy();
    }
}
